#include "Airline.h"
#include "DerivedFlights.h"
#include "DerivedPassengers.h"
#include "Exceptions.h"
#include "SearchUtils.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <ctime>
#include <stdexcept>

// ── Private helpers ────────────────────────────────────────────────────────────

std::string Airline::assignSeat(const std::string& /*flightNum*/,
                                 int totalSeats, int availSeats) {
    // Seat number = sequential index, formatted as letter+number (A1, A2… B1…)
    int seatIndex = totalSeats - availSeats + 1;
    char row = 'A' + ((seatIndex - 1) / 10);
    int  col = ((seatIndex - 1) % 10) + 1;
    return std::string(1, row) + std::to_string(col);
}

int Airline::daysUntilDeparture(const std::string& depDateTime) const {
    // Parse "YYYY-MM-DD HH:MM"
    if (depDateTime.size() < 10) return 0;
    std::tm dep{};
    dep.tm_year = std::stoi(depDateTime.substr(0, 4)) - 1900;
    dep.tm_mon  = std::stoi(depDateTime.substr(5, 2)) - 1;
    dep.tm_mday = std::stoi(depDateTime.substr(8, 2));

    std::time_t depTime = std::mktime(&dep);
    std::time_t now     = std::time(nullptr);
    double diff = std::difftime(depTime, now);
    return static_cast<int>(diff / 86400.0);
}

std::string Airline::departureDateOnly(const std::string& depDateTime) const {
    if (depDateTime.size() >= 10) return depDateTime.substr(0, 10);
    return depDateTime;
}

// ── Flight management ──────────────────────────────────────────────────────────

void Airline::addFlight(std::shared_ptr<Flight> flight) {
    // Ensure no duplicate flight numbers
    if (findFlightByNumber(flight->getFlightNumber()) != nullptr) {
        throw std::invalid_argument("Flight " + flight->getFlightNumber() + " already exists.");
    }
    flights.push_back(flight);
    std::cout << "Flight " << flight->getFlightNumber() << " added.\n";
}

bool Airline::removeFlight(const std::string& flightNum) {
    auto it = std::remove_if(flights.begin(), flights.end(),
        [&flightNum](const std::shared_ptr<Flight>& f) {
            return f->getFlightNumber() == flightNum;
        });
    if (it == flights.end()) return false;
    flights.erase(it, flights.end());
    return true;
}

std::shared_ptr<Flight> Airline::findFlightByNumber(const std::string& flightNum) const {
    return findFirst<Flight>(flights,
        [&flightNum](const Flight& f) { return f.getFlightNumber() == flightNum; });
}

std::vector<std::shared_ptr<Flight>> Airline::findFlightsByRoute(
    const std::string& orig, const std::string& dest) const
{
    return searchEntities<Flight>(flights,
        [&orig, &dest](const Flight& f) {
            return f.getOrigin() == orig && f.getDestination() == dest;
        });
}

std::vector<std::shared_ptr<Flight>> Airline::findFlightsByDate(const std::string& date) const {
    return searchEntities<Flight>(flights,
        [&date, this](const Flight& f) {
            return departureDateOnly(f.getDepartureDateTime()) == date;
        });
}

void Airline::listAllFlights() const {
    if (flights.empty()) { std::cout << "No flights available.\n"; return; }
    for (auto& f : flights) f->displayDetails();
}

// ── Passenger management ───────────────────────────────────────────────────────

void Airline::addPassenger(std::shared_ptr<Passenger> passenger) {
    if (findPassenger(passenger->getPassengerID()) != nullptr) {
        throw std::invalid_argument("Passenger " + passenger->getPassengerID() + " already exists.");
    }
    passengers.push_back(passenger);
    passengerTicketMap[passenger->getPassengerID()] = {};
    std::cout << "Passenger " << passenger->getName() << " registered.\n";
}

bool Airline::removePassenger(const std::string& passengerID) {
    auto it = std::remove_if(passengers.begin(), passengers.end(),
        [&passengerID](const std::shared_ptr<Passenger>& p) {
            return p->getPassengerID() == passengerID;
        });
    if (it == passengers.end()) return false;
    passengers.erase(it, passengers.end());
    passengerTicketMap.erase(passengerID);
    return true;
}

std::shared_ptr<Passenger> Airline::findPassenger(const std::string& passengerID) const {
    return findFirst<Passenger>(passengers,
        [&passengerID](const Passenger& p) { return p.getPassengerID() == passengerID; });
}

void Airline::viewBookingHistory(const std::string& passengerID) const {
    auto pax = findPassenger(passengerID);
    if (!pax) throw NotFoundException("Passenger", passengerID);

    std::cout << "Booking history for " << pax->getName() << " (" << passengerID << "):\n";
    auto mapIt = passengerTicketMap.find(passengerID);
    if (mapIt == passengerTicketMap.end() || mapIt->second.empty()) {
        std::cout << "  No bookings found.\n";
        return;
    }
    for (const auto& tid : mapIt->second) {
        auto tkt = findFirst<Ticket>(tickets,
            [&tid](const Ticket& t) { return t.getTicketID() == tid; });
        if (tkt) std::cout << "  " << *tkt << "\n";
    }
}

// ── Booking & cancellation ─────────────────────────────────────────────────────

std::string Airline::bookTicket(const std::string& passengerID,
                                 const std::string& flightNum) {
    auto pax = findPassenger(passengerID);
    if (!pax) throw NotFoundException("Passenger", passengerID);

    auto flt = findFlightByNumber(flightNum);
    if (!flt) throw NotFoundException("Flight", flightNum);

    // Check for duplicate booking on same flight
    auto mapIt = passengerTicketMap.find(passengerID);
    if (mapIt != passengerTicketMap.end()) {
        for (const auto& tid : mapIt->second) {
            auto tkt = findFirst<Ticket>(tickets,
                [&tid](const Ticket& t) { return t.getTicketID() == tid; });
            if (tkt && tkt->getFlightNumber() == flightNum && tkt->isConfirmed()) {
                throw DuplicateBookingException(passengerID, flightNum);
            }
        }
    }

    // Check seat availability
    if (flt->getAvailableSeats() <= 0) throw FlightFullException(flightNum);

    std::string seat = assignSeat(flightNum, flt->getTotalSeats(), flt->getAvailableSeats());
    double fare = flt->calculateBaseFare() * (1.0 + 0.1 * (pax->getPassengerClass() == "Business" ? 1 : 0)
                                                        + 0.2 * (pax->getPassengerClass() == "FirstClass" ? 1 : 0));
    flt->bookSeat();

    auto ticket = std::make_shared<Ticket>(passengerID, flightNum, seat, fare);
    tickets.push_back(ticket);
    passengerTicketMap[passengerID].push_back(ticket->getTicketID());

    pax->addLoyaltyPoints(fare);

    std::cout << "Booking confirmed! " << *ticket << "\n";
    return ticket->getTicketID();
}

double Airline::cancelTicket(const std::string& ticketID) {
    auto tkt = findFirst<Ticket>(tickets,
        [&ticketID](const Ticket& t) { return t.getTicketID() == ticketID; });

    if (!tkt) throw NotFoundException("Ticket", ticketID);
    if (!tkt->isConfirmed())
        throw InvalidCancellationException("Ticket " + ticketID + " is already cancelled.");

    auto pax = findPassenger(tkt->getPassengerID());
    if (!pax) throw NotFoundException("Passenger", tkt->getPassengerID());

    auto flt = findFlightByNumber(tkt->getFlightNumber());
    if (!flt) throw NotFoundException("Flight", tkt->getFlightNumber());

    int days = daysUntilDeparture(flt->getDepartureDateTime());
    if (days < 0)
        throw InvalidCancellationException("Cannot cancel a past flight.");

    double refundPct = pax->getRefundPercentage(days);
    double refund    = tkt->getFarePaid() * refundPct / 100.0;

    tkt->cancel();
    flt->releaseSeat();

    std::cout << "Ticket " << ticketID << " cancelled. Refund: $"
              << std::fixed << std::setprecision(2) << refund
              << " (" << refundPct << "% of $" << tkt->getFarePaid() << ")\n";
    return refund;
}

// ── Reports ────────────────────────────────────────────────────────────────────

void Airline::reportTodaysDepartures() const {
    // Get today's date as "YYYY-MM-DD"
    std::time_t now = std::time(nullptr);
    std::tm*    ltm = std::localtime(&now);
    std::ostringstream today;
    today << (1900 + ltm->tm_year) << "-"
          << std::setw(2) << std::setfill('0') << (1 + ltm->tm_mon) << "-"
          << std::setw(2) << std::setfill('0') << ltm->tm_mday;

    auto todayFlights = findFlightsByDate(today.str());
    std::cout << "=== Today's Departures (" << today.str() << ") ===\n";
    if (todayFlights.empty()) { std::cout << "No flights departing today.\n"; return; }
    for (auto& f : todayFlights) f->displayDetails();
}

void Airline::reportOccupancy() const {
    std::cout << "=== Flight Occupancy ===\n";
    if (flights.empty()) { std::cout << "No flights.\n"; return; }

    // Sort a copy by occupancy descending
    auto sorted = flights;
    std::sort(sorted.begin(), sorted.end(),
        [](const std::shared_ptr<Flight>& a, const std::shared_ptr<Flight>& b) {
            return a->occupancyPercent() > b->occupancyPercent();
        });

    for (auto& f : sorted) {
        std::cout << f->getFlightNumber() << "  "
                  << f->getOrigin() << "->" << f->getDestination()
                  << "  Occupancy: " << std::fixed << std::setprecision(1)
                  << f->occupancyPercent() << "%\n";
    }
}

void Airline::reportTop5Revenue() const {
    // Build revenue map per flight from confirmed tickets
    std::map<std::string, double> revenueMap;
    for (auto& f : flights) revenueMap[f->getFlightNumber()] = 0.0;
    for (auto& t : tickets) {
        if (t->isConfirmed()) revenueMap[t->getFlightNumber()] += t->getFarePaid();
    }

    // Convert to vector and sort descending by revenue
    std::vector<std::pair<std::string, double>> rev(revenueMap.begin(), revenueMap.end());
    std::sort(rev.begin(), rev.end(),
        [](const auto& a, const auto& b) { return a.second > b.second; });

    std::cout << "=== Top 5 Highest-Revenue Flights ===\n";
    int count = 0;
    for (auto& [fn, revenue] : rev) {
        if (count++ >= 5) break;
        std::cout << "  " << count << ". " << fn
                  << "  Revenue: $" << std::fixed << std::setprecision(2) << revenue << "\n";
    }
}

// ── Persistence ────────────────────────────────────────────────────────────────

void Airline::saveToFile(const std::string& filename) const {
    std::ofstream ofs(filename);
    if (!ofs) throw std::runtime_error("Cannot open file for writing: " + filename);

    // Section: TICKET_COUNTER
    ofs << "TICKET_COUNTER " << Ticket::getCounter() << "\n";

    // Section: FLIGHTS  type|fn|orig|dest|depDT|total|avail|extra
    ofs << "FLIGHTS " << flights.size() << "\n";
    for (auto& f : flights) {
        ofs << f->getType() << "|"
            << f->getFlightNumber() << "|"
            << f->getOrigin() << "|"
            << f->getDestination() << "|"
            << f->getDepartureDateTime() << "|"
            << f->getTotalSeats() << "|"
            << f->getAvailableSeats() << "|"
            << f->getExtraData() << "\n";
    }

    // Section: PASSENGERS  class|id|name|email|loyalty
    ofs << "PASSENGERS " << passengers.size() << "\n";
    for (auto& p : passengers) {
        ofs << p->getPassengerClass() << "|"
            << p->getPassengerID() << "|"
            << p->getName() << "|"
            << p->getEmail() << "|"
            << p->getLoyaltyPoints() << "\n";
    }

    // Section: TICKETS  id|passID|flightNum|seat|fare|status
    ofs << "TICKETS " << tickets.size() << "\n";
    for (auto& t : tickets) {
        ofs << t->getTicketID() << "|"
            << t->getPassengerID() << "|"
            << t->getFlightNumber() << "|"
            << t->getSeatNumber() << "|"
            << t->getFarePaid() << "|"
            << (t->isConfirmed() ? "CONFIRMED" : "CANCELLED") << "\n";
    }

    std::cout << "State saved to " << filename << "\n";
}

void Airline::loadFromFile(const std::string& filename) {
    std::ifstream ifs(filename);
    if (!ifs) {
        std::cout << "No saved state found (" << filename << "). Starting fresh.\n";
        return;
    }

    flights.clear();
    passengers.clear();
    tickets.clear();
    passengerTicketMap.clear();

    std::string line;

    // Ticket counter
    int counter = 1;
    ifs >> line >> counter; // "TICKET_COUNTER N"
    Ticket::setCounter(counter);
    ifs.ignore();

    // Flights
    int numFlights = 0;
    ifs >> line >> numFlights;
    ifs.ignore();
    for (int i = 0; i < numFlights; ++i) {
        std::getline(ifs, line);
        std::istringstream ss(line);
        std::string type, fn, orig, dest, depDT, extra;
        int total, avail;
        std::getline(ss, type, '|');
        std::getline(ss, fn, '|');
        std::getline(ss, orig, '|');
        std::getline(ss, dest, '|');
        std::getline(ss, depDT, '|');
        ss >> total; ss.ignore();
        ss >> avail; ss.ignore();
        std::getline(ss, extra);

        std::shared_ptr<Flight> flt;
        if (type == "Domestic") {
            flt = std::make_shared<DomesticFlight>(fn, orig, dest, depDT, total, extra);
        } else if (type == "International") {
            // extra = "country,visa"
            auto comma = extra.find(',');
            std::string country = extra.substr(0, comma);
            bool visa = (extra.substr(comma + 1) == "1");
            flt = std::make_shared<InternationalFlight>(fn, orig, dest, depDT, total, country, visa);
        } else {
            flt = std::make_shared<CharterFlight>(fn, orig, dest, depDT, total, extra);
        }
        flt->setAvailableSeats(avail);
        flights.push_back(flt);
    }

    // Passengers
    int numPax = 0;
    ifs >> line >> numPax;
    ifs.ignore();
    for (int i = 0; i < numPax; ++i) {
        std::getline(ifs, line);
        std::istringstream ss(line);
        std::string cls, id, name, email;
        int lp;
        std::getline(ss, cls, '|');
        std::getline(ss, id, '|');
        std::getline(ss, name, '|');
        std::getline(ss, email, '|');
        ss >> lp;

        std::shared_ptr<Passenger> pax;
        if (cls == "Economy")
            pax = std::make_shared<EconomyPassenger>(id, name, email, lp);
        else if (cls == "Business")
            pax = std::make_shared<BusinessPassenger>(id, name, email, lp);
        else
            pax = std::make_shared<FirstClassPassenger>(id, name, email, lp);

        passengers.push_back(pax);
        passengerTicketMap[id] = {};
    }

    // Tickets
    int numTkts = 0;
    ifs >> line >> numTkts;
    ifs.ignore();
    for (int i = 0; i < numTkts; ++i) {
        std::getline(ifs, line);
        std::istringstream ss(line);
        std::string tid, pid, fn, seat, statusStr;
        double fare;
        std::getline(ss, tid, '|');
        std::getline(ss, pid, '|');
        std::getline(ss, fn, '|');
        std::getline(ss, seat, '|');
        ss >> fare; ss.ignore();
        std::getline(ss, statusStr);

        auto tkt = std::make_shared<Ticket>(pid, fn, seat, fare);
        tkt->setTicketID(tid);
        if (statusStr == "CANCELLED") tkt->cancel();
        tickets.push_back(tkt);
        passengerTicketMap[pid].push_back(tid);
    }

    std::cout << "State loaded from " << filename << "\n";
}
