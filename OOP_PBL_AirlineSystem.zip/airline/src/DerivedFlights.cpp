#include "DerivedFlights.h"
#include <iostream>
#include <iomanip>

// ─── DomesticFlight ───────────────────────────────────────────────────────────

double DomesticFlight::calculateBaseFare() const {
    // Domestic: flat base + small per-seat premium
    return 80.0 + (totalSeats < 100 ? 20.0 : 10.0);
}

void DomesticFlight::displayDetails() const {
    std::cout << *this << "  Region: " << region << "\n";
}

// ─── InternationalFlight ──────────────────────────────────────────────────────

double InternationalFlight::calculateBaseFare() const {
    // International: higher base + visa surcharge if required
    double base = 350.0;
    if (visaRequired) base += 50.0;
    return base;
}

void InternationalFlight::displayDetails() const {
    std::cout << *this
              << "  Country: " << destinationCountry
              << "  Visa Required: " << (visaRequired ? "Yes" : "No") << "\n";
}

// ─── CharterFlight ────────────────────────────────────────────────────────────

double CharterFlight::calculateBaseFare() const {
    // Charter: premium flat rate
    return 600.0;
}

void CharterFlight::displayDetails() const {
    std::cout << *this << "  Contract Holder: " << contractHolder << "\n";
}
