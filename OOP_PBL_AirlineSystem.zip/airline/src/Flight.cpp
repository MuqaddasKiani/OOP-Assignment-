#include "Flight.h"
#include <iomanip>

bool Flight::bookSeat() {
    if (availableSeats <= 0) return false;
    --availableSeats;
    return true;
}

void Flight::releaseSeat() {
    if (availableSeats < totalSeats) ++availableSeats;
}

double Flight::occupancyPercent() const {
    if (totalSeats == 0) return 0.0;
    return ((totalSeats - availableSeats) * 100.0) / totalSeats;
}

std::ostream& operator<<(std::ostream& os, const Flight& f) {
    os << "[" << f.getType() << "] " << f.flightNumber
       << "  " << f.origin << " -> " << f.destination
       << "  Dep: " << f.departureDateTime
       << "  Seats: " << f.availableSeats << "/" << f.totalSeats
       << "  Base Fare: $" << std::fixed << std::setprecision(2) << f.calculateBaseFare();
    return os;
}
