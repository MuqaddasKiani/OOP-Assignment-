#include "Passenger.h"
#include <iostream>
#include <iomanip>
#include <cmath>

void Passenger::addLoyaltyPoints(double fare) {
    // Points = floor(fare * multiplier / 10)
    loyaltyPoints += static_cast<int>(std::floor(fare * getLoyaltyMultiplier() / 10.0));
}

void Passenger::displayInfo() const {
    std::cout << *this;
}

std::ostream& operator<<(std::ostream& os, const Passenger& p) {
    os << "[" << p.getPassengerClass() << "] "
       << p.passengerID << "  " << p.name
       << "  Email: " << p.email
       << "  Loyalty Pts: " << p.loyaltyPoints
       << "  Baggage: " << p.getBaggageAllowanceKg() << " kg";
    return os;
}
