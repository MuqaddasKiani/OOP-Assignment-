#include "Ticket.h"
#include <iomanip>
#include <sstream>

int Ticket::ticketCounter = 1;

Ticket::Ticket(const std::string& pid, const std::string& fn,
               const std::string& seat, double fare)
    : passengerID(pid), flightNumber(fn), seatNumber(seat),
      farePaid(fare), status(BookingStatus::CONFIRMED)
{
    // Auto-generate ticket ID: TKT0001, TKT0002, …
    std::ostringstream oss;
    oss << "TKT" << std::setw(4) << std::setfill('0') << ticketCounter++;
    ticketID = oss.str();
}

std::ostream& operator<<(std::ostream& os, const Ticket& t) {
    os << "Ticket[" << t.ticketID << "]"
       << "  Passenger: " << t.passengerID
       << "  Flight: "    << t.flightNumber
       << "  Seat: "      << t.seatNumber
       << "  Fare: $"     << std::fixed << std::setprecision(2) << t.farePaid
       << "  Status: "    << (t.status == BookingStatus::CONFIRMED ? "CONFIRMED" : "CANCELLED");
    return os;
}
