#include "Airline.h"
#include "DerivedFlights.h"
#include "DerivedPassengers.h"
#include "Exceptions.h"

#include <iostream>
#include <limits>
#include <string>
#include <memory>

static const std::string DATA_FILE = "data/airline_state.dat";

// ── Input helpers ──────────────────────────────────────────────────────────────

int getInt(const std::string& prompt) {
    int val;
    while (true) {
        std::cout << prompt;
        if (std::cin >> val) { std::cin.ignore(); return val; }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "  Invalid input. Please enter a number.\n";
    }
}

std::string getLine(const std::string& prompt) {
    std::cout << prompt;
    std::string s;
    std::getline(std::cin, s);
    return s;
}

// ── Sub-menus ──────────────────────────────────────────────────────────────────

void flightMenu(Airline& airline) {
    while (true) {
        std::cout << "\n--- Flight Management ---\n"
                  << "1. Add flight\n2. Remove flight\n"
                  << "3. Find by flight number\n4. Find by route\n"
                  << "5. Find by date\n6. List all flights\n0. Back\n";
        int ch = getInt("Choice: ");
        try {
            if (ch == 0) break;
            if (ch == 1) {
                std::cout << "Type: 1=Domestic  2=International  3=Charter\n";
                int t = getInt("Type: ");
                std::string fn  = getLine("Flight number: ");
                std::string org = getLine("Origin: ");
                std::string dst = getLine("Destination: ");
                std::string dep = getLine("Departure (YYYY-MM-DD HH:MM): ");
                int seats = getInt("Total seats: ");

                if (t == 1) {
                    std::string region = getLine("Region: ");
                    airline.addFlight(std::make_shared<DomesticFlight>(fn, org, dst, dep, seats, region));
                } else if (t == 2) {
                    std::string country = getLine("Destination country: ");
                    int visa = getInt("Visa required? (1=Yes 0=No): ");
                    airline.addFlight(std::make_shared<InternationalFlight>(fn, org, dst, dep, seats, country, visa == 1));
                } else {
                    std::string holder = getLine("Contract holder: ");
                    airline.addFlight(std::make_shared<CharterFlight>(fn, org, dst, dep, seats, holder));
                }
            } else if (ch == 2) {
                std::string fn = getLine("Flight number to remove: ");
                if (airline.removeFlight(fn)) std::cout << "Flight removed.\n";
                else std::cout << "Flight not found.\n";
            } else if (ch == 3) {
                std::string fn = getLine("Flight number: ");
                auto flt = airline.findFlightByNumber(fn);
                if (flt) flt->displayDetails();
                else     std::cout << "Not found.\n";
            } else if (ch == 4) {
                std::string org = getLine("Origin: ");
                std::string dst = getLine("Destination: ");
                auto res = airline.findFlightsByRoute(org, dst);
                if (res.empty()) std::cout << "No flights on that route.\n";
                else for (auto& f : res) f->displayDetails();
            } else if (ch == 5) {
                std::string date = getLine("Date (YYYY-MM-DD): ");
                auto res = airline.findFlightsByDate(date);
                if (res.empty()) std::cout << "No flights on that date.\n";
                else for (auto& f : res) f->displayDetails();
            } else if (ch == 6) {
                airline.listAllFlights();
            }
        } catch (const std::exception& e) {
            std::cout << "Error: " << e.what() << "\n";
        }
    }
}

void passengerMenu(Airline& airline) {
    while (true) {
        std::cout << "\n--- Passenger Management ---\n"
                  << "1. Register passenger\n2. Remove passenger\n"
                  << "3. View booking history\n0. Back\n";
        int ch = getInt("Choice: ");
        try {
            if (ch == 0) break;
            if (ch == 1) {
                std::cout << "Class: 1=Economy  2=Business  3=FirstClass\n";
                int cls = getInt("Class: ");
                std::string id    = getLine("Passenger ID: ");
                std::string name  = getLine("Name: ");
                std::string email = getLine("Email: ");
                if (cls == 1)
                    airline.addPassenger(std::make_shared<EconomyPassenger>(id, name, email));
                else if (cls == 2)
                    airline.addPassenger(std::make_shared<BusinessPassenger>(id, name, email));
                else
                    airline.addPassenger(std::make_shared<FirstClassPassenger>(id, name, email));
            } else if (ch == 2) {
                std::string id = getLine("Passenger ID to remove: ");
                if (airline.removePassenger(id)) std::cout << "Passenger removed.\n";
                else std::cout << "Passenger not found.\n";
            } else if (ch == 3) {
                std::string id = getLine("Passenger ID: ");
                airline.viewBookingHistory(id);
            }
        } catch (const std::exception& e) {
            std::cout << "Error: " << e.what() << "\n";
        }
    }
}

void bookingMenu(Airline& airline) {
    while (true) {
        std::cout << "\n--- Booking & Cancellation ---\n"
                  << "1. Book a ticket\n2. Cancel a ticket\n0. Back\n";
        int ch = getInt("Choice: ");
        try {
            if (ch == 0) break;
            if (ch == 1) {
                std::string pid = getLine("Passenger ID: ");
                std::string fn  = getLine("Flight number: ");
                airline.bookTicket(pid, fn);
            } else if (ch == 2) {
                std::string tid = getLine("Ticket ID (e.g. TKT0001): ");
                airline.cancelTicket(tid);
            }
        } catch (const FlightFullException& e)            { std::cout << "Error: " << e.what() << "\n"; }
          catch (const InvalidCancellationException& e)   { std::cout << "Error: " << e.what() << "\n"; }
          catch (const DuplicateBookingException& e)       { std::cout << "Error: " << e.what() << "\n"; }
          catch (const NotFoundException& e)               { std::cout << "Error: " << e.what() << "\n"; }
          catch (const std::exception& e)                  { std::cout << "Error: " << e.what() << "\n"; }
    }
}

void reportsMenu(Airline& airline) {
    while (true) {
        std::cout << "\n--- Reports ---\n"
                  << "1. Today's departures\n2. Occupancy per flight\n"
                  << "3. Top 5 revenue flights\n0. Back\n";
        int ch = getInt("Choice: ");
        if (ch == 0) break;
        if (ch == 1) airline.reportTodaysDepartures();
        if (ch == 2) airline.reportOccupancy();
        if (ch == 3) airline.reportTop5Revenue();
    }
}

// ── Main ───────────────────────────────────────────────────────────────────────

int main() {
    Airline skylink("SkyLink Airways");
    skylink.loadFromFile(DATA_FILE);

    std::cout << "=========================================\n"
              << "   Welcome to SkyLink Airways System\n"
              << "=========================================\n";

    while (true) {
        std::cout << "\n=== Main Menu ===\n"
                  << "1. Flight Management\n"
                  << "2. Passenger Management\n"
                  << "3. Booking & Cancellation\n"
                  << "4. Reports\n"
                  << "0. Save & Exit\n";
        int ch = getInt("Choice: ");
        if (ch == 0) {
            skylink.saveToFile(DATA_FILE);
            std::cout << "Goodbye!\n";
            break;
        }
        if (ch == 1) flightMenu(skylink);
        else if (ch == 2) passengerMenu(skylink);
        else if (ch == 3) bookingMenu(skylink);
        else if (ch == 4) reportsMenu(skylink);
        else std::cout << "Invalid choice.\n";
    }
    return 0;
}
