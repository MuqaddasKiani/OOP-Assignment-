# SkyLink Airways — Airline Reservation & Flight Management System

A console-based C++ application for managing flights, passengers, ticket bookings, cancellations, and reports.
Built for the OOP (C++) Problem-Based Learning assignment.

---

## Project Structure

```
airline/
├── include/                  # Header files (.h)
│   ├── Exceptions.h          # Custom exception classes
│   ├── Flight.h              # Abstract base class for flights
│   ├── DerivedFlights.h      # DomesticFlight, InternationalFlight, CharterFlight
│   ├── Passenger.h           # Abstract base class for passengers
│   ├── DerivedPassengers.h   # EconomyPassenger, BusinessPassenger, FirstClassPassenger
│   ├── Ticket.h              # Ticket class (links passenger + flight)
│   ├── SearchUtils.h         # Generic template search utility
│   └── Airline.h             # Main aggregator class
├── src/                      # Implementation files (.cpp)
│   ├── main.cpp              # Menu-driven console interface
│   ├── Flight.cpp
│   ├── DerivedFlights.cpp
│   ├── Passenger.cpp
│   ├── Ticket.cpp
│   └── Airline.cpp
├── data/
│   └── airline_state.dat     # Persistence file (auto-created on exit)
├── Makefile
└── README.md
```

---

## How to Build

### Requirements
- g++ with C++17 support (g++ 7 or newer)
- make

### Build Command
```bash
cd airline
make
```
This compiles all source files and produces the `airline_system` executable.

### Clean Build Artifacts
```bash
make clean
```

---

## How to Run

```bash
./airline_system
```

On startup, the program automatically loads saved state from `data/airline_state.dat`.
On exit (option 0), it saves the full state back to the same file.

A sample data file with **10 flights** and **8 passengers** is included so you can test immediately.

---

## How to Use

### Main Menu
```
=== Main Menu ===
1. Flight Management
2. Passenger Management
3. Booking & Cancellation
4. Reports
0. Save & Exit
```

### Flight Management
| Option | Description |
|--------|-------------|
| Add flight | Choose type (Domestic / International / Charter), then enter details |
| Remove flight | Enter flight number |
| Find by number | Exact match search |
| Find by route | Enter origin and destination |
| Find by date | Enter date as YYYY-MM-DD |
| List all | Displays all flights with full details |

**Flight types:**
- **Domestic** — requires a region (e.g., North, South). Base fare: $90–$100.
- **International** — requires destination country and visa flag. Base fare: $350–$400.
- **Charter** — requires contract holder name. Base fare: $600.

### Passenger Management
| Option | Description |
|--------|-------------|
| Register | Choose class (Economy / Business / First Class), enter ID, name, email |
| Remove | Enter passenger ID |
| View history | Lists all tickets booked by a passenger |

### Booking & Cancellation
| Option | Description |
|--------|-------------|
| Book ticket | Enter passenger ID + flight number; system assigns seat automatically |
| Cancel ticket | Enter ticket ID (e.g., TKT0001); refund is calculated based on class and days left |

**Refund rules (days before departure):**
| Class | >7 days | ≤7 days |
|-------|---------|---------|
| Economy | 50% | 20% |
| Business (>3 days) | 75% | 40% |
| First Class (>1 day) | 90% | 60% |

### Reports
| Option | Description |
|--------|-------------|
| Today's departures | Lists all flights departing on today's date |
| Occupancy per flight | Shows occupancy % for all flights, sorted descending |
| Top 5 revenue flights | Lists top 5 flights by total ticket revenue |

---

## OOP Features Used

| Feature | Where Used |
|---------|------------|
| Abstract class + pure virtual | `Flight` (calculateBaseFare, displayDetails, getType), `Passenger` (getRefundPercentage, etc.) |
| Inheritance | `DomesticFlight`, `InternationalFlight`, `CharterFlight` from `Flight`; `Economy/Business/FirstClass` from `Passenger` |
| Polymorphism | Fare calculation, refund calculation, display — all resolved at runtime via virtual dispatch |
| Operator overloading | `<<` for `Flight`, `Passenger`, `Ticket`; `==` for `Ticket` by ID |
| Function template | `searchEntities<T>()` and `findFirst<T>()` in `SearchUtils.h` — generic over any entity type |
| Custom exceptions | `FlightFullException`, `InvalidCancellationException`, `DuplicateBookingException`, `NotFoundException` |
| STL containers | `std::vector` for flights/passengers/tickets; `std::map` for passenger-ticket lookup |
| STL algorithms | `std::sort`, `std::find_if`, `std::copy_if`, `std::remove_if` |
| Smart pointers | `std::shared_ptr` throughout — no raw `new`/`delete` |
| File I/O | `saveToFile()` / `loadFromFile()` in `Airline.cpp` |

---

## Sample Passenger IDs (pre-loaded)
| ID | Name | Class |
|----|------|-------|
| P001 | Ali Hassan | Economy |
| P002 | Sara Khan | Economy |
| P003 | Ahmed Raza | Business |
| P004 | Fatima Malik | Business |
| P005 | Usman Sheikh | First Class |
| P006 | Ayesha Siddiqui | First Class |
| P007 | Bilal Chaudhry | Economy |
| P008 | Zara Qureshi | Business |

## Sample Flight Numbers (pre-loaded)
`SK101`, `SK102`, `SK103`, `SK104` (Domestic),
`SK201`, `SK202`, `SK203`, `SK204` (International),
`SK301`, `SK302` (Charter)

---

## Compilation Notes
- Standard: `g++ -std=c++17 -Wall -Wextra`
- Compiles with **zero warnings**
- Tested on Ubuntu 24 with g++ 11
