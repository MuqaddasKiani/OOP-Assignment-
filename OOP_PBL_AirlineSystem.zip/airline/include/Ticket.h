#ifndef TICKET_H
#define TICKET_H

#include <string>
#include <iostream>

enum class BookingStatus { CONFIRMED, CANCELLED };

// Links one passenger to one flight
class Ticket {
private:
    std::string ticketID;
    std::string passengerID;
    std::string flightNumber;
    std::string seatNumber;
    double farePaid;
    BookingStatus status;

    static int ticketCounter; // used to auto-generate ticket IDs

public:
    Ticket(const std::string& pid, const std::string& fn,
           const std::string& seat, double fare);

    // Getters
    std::string   getTicketID()     const { return ticketID; }
    std::string   getPassengerID()  const { return passengerID; }
    std::string   getFlightNumber() const { return flightNumber; }
    std::string   getSeatNumber()   const { return seatNumber; }
    double        getFarePaid()     const { return farePaid; }
    BookingStatus getStatus()       const { return status; }

    // Cancel this ticket
    void cancel() { status = BookingStatus::CANCELLED; }

    bool isConfirmed() const { return status == BookingStatus::CONFIRMED; }

    // Operator overloads
    bool operator==(const Ticket& other) const { return ticketID == other.ticketID; }
    friend std::ostream& operator<<(std::ostream& os, const Ticket& t);

    // For file I/O — set ticketID and counter explicitly on load
    void setTicketID(const std::string& id) { ticketID = id; }
    static void setCounter(int c) { ticketCounter = c; }
    static int  getCounter()      { return ticketCounter; }
};

#endif // TICKET_H
