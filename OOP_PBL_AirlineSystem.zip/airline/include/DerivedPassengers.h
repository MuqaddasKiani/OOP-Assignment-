#ifndef DERIVED_PASSENGERS_H
#define DERIVED_PASSENGERS_H

#include "Passenger.h"

// ─── Economy Passenger ─────────────────────────────────────────────────────────
class EconomyPassenger : public Passenger {
public:
    EconomyPassenger(const std::string& id, const std::string& nm,
                     const std::string& em, int lp = 0)
        : Passenger(id, nm, em, lp) {}

    double getBaggageAllowanceKg()  const override { return 20.0; }
    double getLoyaltyMultiplier()   const override { return 1.0; }
    // Economy: 50% refund if >7 days out, else 20%
    double getRefundPercentage(int daysBeforeDeparture) const override {
        return (daysBeforeDeparture > 7) ? 50.0 : 20.0;
    }
    std::string getPassengerClass() const override { return "Economy"; }
};

// ─── Business Passenger ────────────────────────────────────────────────────────
class BusinessPassenger : public Passenger {
public:
    BusinessPassenger(const std::string& id, const std::string& nm,
                      const std::string& em, int lp = 0)
        : Passenger(id, nm, em, lp) {}

    double getBaggageAllowanceKg()  const override { return 32.0; }
    double getLoyaltyMultiplier()   const override { return 1.5; }
    // Business: 75% refund if >3 days out, else 40%
    double getRefundPercentage(int daysBeforeDeparture) const override {
        return (daysBeforeDeparture > 3) ? 75.0 : 40.0;
    }
    std::string getPassengerClass() const override { return "Business"; }
};

// ─── First Class Passenger ─────────────────────────────────────────────────────
class FirstClassPassenger : public Passenger {
public:
    FirstClassPassenger(const std::string& id, const std::string& nm,
                        const std::string& em, int lp = 0)
        : Passenger(id, nm, em, lp) {}

    double getBaggageAllowanceKg()  const override { return 50.0; }
    double getLoyaltyMultiplier()   const override { return 2.0; }
    // First: 90% refund if >1 day out, else 60%
    double getRefundPercentage(int daysBeforeDeparture) const override {
        return (daysBeforeDeparture > 1) ? 90.0 : 60.0;
    }
    std::string getPassengerClass() const override { return "FirstClass"; }
};

#endif // DERIVED_PASSENGERS_H
