#ifndef SEARCH_UTILS_H
#define SEARCH_UTILS_H

#include <vector>
#include <memory>
#include <functional>
#include <algorithm>

// Generic search utility — works for any type T stored in a shared_ptr vector.
// Predicate is a callable that takes a const T& and returns bool.
template <typename T>
std::vector<std::shared_ptr<T>> searchEntities(
    const std::vector<std::shared_ptr<T>>& collection,
    std::function<bool(const T&)> predicate)
{
    std::vector<std::shared_ptr<T>> results;
    std::copy_if(collection.begin(), collection.end(),
                 std::back_inserter(results),
                 [&predicate](const std::shared_ptr<T>& item) {
                     return predicate(*item);
                 });
    return results;
}

// Generic find-first utility — returns nullptr if not found
template <typename T>
std::shared_ptr<T> findFirst(
    const std::vector<std::shared_ptr<T>>& collection,
    std::function<bool(const T&)> predicate)
{
    auto it = std::find_if(collection.begin(), collection.end(),
                           [&predicate](const std::shared_ptr<T>& item) {
                               return predicate(*item);
                           });
    return (it != collection.end()) ? *it : nullptr;
}

#endif // SEARCH_UTILS_H
