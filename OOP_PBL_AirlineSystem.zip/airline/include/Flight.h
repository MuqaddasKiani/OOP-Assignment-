#ifndef FLIGHT_H
#define FLIGHT_H

#include <string>
#include <iostream>

// Abstract base class for all flight types
class Flight {
protected:
    std::string flightNumber;
    std::string origin;
    std::string destination;
    std::string departureDateTime; // "YYYY-MM-DD HH:MM"
    int totalSeats;
    int availableSeats;

public:
    Flight(const std::string& fn, const std::string& orig, const std::string& dest,
           const std::string& depDT, int seats)
        : flightNumber(fn), origin(orig), destination(dest),
          departureDateTime(depDT), totalSeats(seats), availableSeats(seats) {}

    virtual ~Flight() = default;

    // Pure virtual functions — must be implemented by derived classes
    virtual double calculateBaseFare() const = 0;
    virtual void displayDetails() const = 0;
    virtual std::string getType() const = 0;
    virtual std::string getExtraData() const = 0; // for file persistence

    // Getters
    std::string getFlightNumber()    const { return flightNumber; }
    std::string getOrigin()          const { return origin; }
    std::string getDestination()     const { return destination; }
    std::string getDepartureDateTime() const { return departureDateTime; }
    int getTotalSeats()              const { return totalSeats; }
    int getAvailableSeats()          const { return availableSeats; }

    // Setters
    void setAvailableSeats(int s) { availableSeats = s; }

    // Book / release one seat
    bool bookSeat();
    void releaseSeat();

    // Occupancy as percentage
    double occupancyPercent() const;

    // Overloaded output operator
    friend std::ostream& operator<<(std::ostream& os, const Flight& f);
};

#endif // FLIGHT_H
