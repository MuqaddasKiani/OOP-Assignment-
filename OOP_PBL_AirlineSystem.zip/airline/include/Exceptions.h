#ifndef EXCEPTIONS_H
#define EXCEPTIONS_H

#include <stdexcept>
#include <string>

// Custom exception: thrown when a flight has no available seats
class FlightFullException : public std::runtime_error {
public:
    explicit FlightFullException(const std::string& flightNum)
        : std::runtime_error("Flight " + flightNum + " is fully booked.") {}
};

// Custom exception: thrown for invalid cancellation attempts
class InvalidCancellationException : public std::runtime_error {
public:
    explicit InvalidCancellationException(const std::string& msg)
        : std::runtime_error("Cancellation error: " + msg) {}
};

// Custom exception: thrown when a duplicate booking is attempted
class DuplicateBookingException : public std::runtime_error {
public:
    explicit DuplicateBookingException(const std::string& passID, const std::string& flightNum)
        : std::runtime_error("Passenger " + passID + " already has a ticket on flight " + flightNum + ".") {}
};

// Custom exception: thrown when an entity is not found
class NotFoundException : public std::runtime_error {
public:
    explicit NotFoundException(const std::string& entity, const std::string& id)
        : std::runtime_error(entity + " with ID '" + id + "' not found.") {}
};

#endif // EXCEPTIONS_H
