#ifndef AIRLINE_H
#define AIRLINE_H

#include "Flight.h"
#include "Passenger.h"
#include "Ticket.h"
#include <vector>
#include <map>
#include <memory>
#include <string>

class Airline {
private:
    std::string airlineName;

    // STL containers
    std::vector<std::shared_ptr<Flight>>    flights;
    std::vector<std::shared_ptr<Passenger>> passengers;
    std::vector<std::shared_ptr<Ticket>>    tickets;

    // map: passengerID -> list of ticketIDs (fast lookup for booking history)
    std::map<std::string, std::vector<std::string>> passengerTicketMap;

    // Helper: assign next available seat label (A1, A2 … Z99)
    std::string assignSeat(const std::string& flightNum, int totalSeats, int availSeats);

    // Helper: days between today's date (from system) and departure date string "YYYY-MM-DD HH:MM"
    int daysUntilDeparture(const std::string& depDateTime) const;

    // Helper: get departure date only (first 10 chars of "YYYY-MM-DD HH:MM")
    std::string departureDateOnly(const std::string& depDateTime) const;

public:
    explicit Airline(const std::string& name) : airlineName(name) {}

    // ── Flight management ───────────────────────────────────────────────────
    void addFlight(std::shared_ptr<Flight> flight);
    bool removeFlight(const std::string& flightNum);
    std::shared_ptr<Flight> findFlightByNumber(const std::string& flightNum) const;
    std::vector<std::shared_ptr<Flight>> findFlightsByRoute(const std::string& orig,
                                                            const std::string& dest) const;
    std::vector<std::shared_ptr<Flight>> findFlightsByDate(const std::string& date) const;
    void listAllFlights() const;

    // ── Passenger management ────────────────────────────────────────────────
    void addPassenger(std::shared_ptr<Passenger> passenger);
    bool removePassenger(const std::string& passengerID);
    std::shared_ptr<Passenger> findPassenger(const std::string& passengerID) const;
    void viewBookingHistory(const std::string& passengerID) const;

    // ── Booking & cancellation ──────────────────────────────────────────────
    std::string bookTicket(const std::string& passengerID, const std::string& flightNum);
    double cancelTicket(const std::string& ticketID);

    // ── Reports ─────────────────────────────────────────────────────────────
    void reportTodaysDepartures() const;
    void reportOccupancy()        const;
    void reportTop5Revenue()      const;

    // ── Persistence ─────────────────────────────────────────────────────────
    void saveToFile(const std::string& filename) const;
    void loadFromFile(const std::string& filename);

    const std::vector<std::shared_ptr<Ticket>>& getTickets() const { return tickets; }
};

#endif // AIRLINE_H
