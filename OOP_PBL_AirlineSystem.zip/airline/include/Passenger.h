#ifndef PASSENGER_H
#define PASSENGER_H

#include <string>
#include <iostream>

// Abstract base class for all passenger types
class Passenger {
protected:
    std::string passengerID;
    std::string name;
    std::string email;
    int loyaltyPoints;

public:
    Passenger(const std::string& id, const std::string& nm,
              const std::string& em, int lp = 0)
        : passengerID(id), name(nm), email(em), loyaltyPoints(lp) {}

    virtual ~Passenger() = default;

    // Pure virtual — different class types have different rules
    virtual double getBaggageAllowanceKg()   const = 0;
    virtual double getLoyaltyMultiplier()    const = 0;
    virtual double getRefundPercentage(int daysBeforeDeparture) const = 0;
    virtual std::string getPassengerClass()  const = 0;

    // Getters
    std::string getPassengerID() const { return passengerID; }
    std::string getName()        const { return name; }
    std::string getEmail()       const { return email; }
    int getLoyaltyPoints()       const { return loyaltyPoints; }

    // Add loyalty points based on fare paid
    void addLoyaltyPoints(double fare);

    void displayInfo() const;
    friend std::ostream& operator<<(std::ostream& os, const Passenger& p);
};

#endif // PASSENGER_H
