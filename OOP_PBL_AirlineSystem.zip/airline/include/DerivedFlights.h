#ifndef DERIVED_FLIGHTS_H
#define DERIVED_FLIGHTS_H

#include "Flight.h"
#include <string>

// ─── Domestic Flight ───────────────────────────────────────────────────────────
class DomesticFlight : public Flight {
private:
    std::string region; // e.g., "North", "South"

public:
    DomesticFlight(const std::string& fn, const std::string& orig, const std::string& dest,
                   const std::string& depDT, int seats, const std::string& region)
        : Flight(fn, orig, dest, depDT, seats), region(region) {}

    double calculateBaseFare() const override;
    void displayDetails()      const override;
    std::string getType()      const override { return "Domestic"; }
    std::string getExtraData() const override { return region; }

    std::string getRegion() const { return region; }
};

// ─── International Flight ──────────────────────────────────────────────────────
class InternationalFlight : public Flight {
private:
    std::string destinationCountry;
    bool visaRequired;

public:
    InternationalFlight(const std::string& fn, const std::string& orig, const std::string& dest,
                        const std::string& depDT, int seats,
                        const std::string& country, bool visa)
        : Flight(fn, orig, dest, depDT, seats),
          destinationCountry(country), visaRequired(visa) {}

    double calculateBaseFare() const override;
    void displayDetails()      const override;
    std::string getType()      const override { return "International"; }
    std::string getExtraData() const override {
        return destinationCountry + "," + (visaRequired ? "1" : "0");
    }

    std::string getDestinationCountry() const { return destinationCountry; }
    bool getVisaRequired()              const { return visaRequired; }
};

// ─── Charter Flight ────────────────────────────────────────────────────────────
class CharterFlight : public Flight {
private:
    std::string contractHolder; // company or individual that chartered the flight

public:
    CharterFlight(const std::string& fn, const std::string& orig, const std::string& dest,
                  const std::string& depDT, int seats,
                  const std::string& holder)
        : Flight(fn, orig, dest, depDT, seats), contractHolder(holder) {}

    double calculateBaseFare() const override;
    void displayDetails()      const override;
    std::string getType()      const override { return "Charter"; }
    std::string getExtraData() const override { return contractHolder; }

    std::string getContractHolder() const { return contractHolder; }
};

#endif // DERIVED_FLIGHTS_H
