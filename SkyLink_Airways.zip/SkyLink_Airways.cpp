#include <iostream>
#include <vector>
#include <map>
#include <memory>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdexcept>
#include <ctime>
using namespace std;

// SkyLink Airways - Console Airline Reservation System
class FlightFullException : public runtime_error { public: FlightFullException():runtime_error("Flight is full."){} };
class NotFoundException : public runtime_error { public: NotFoundException():runtime_error("Record not found."){} };
class DuplicateBookingException : public runtime_error { public: DuplicateBookingException():runtime_error("Passenger already booked this flight."){} };
class InvalidCancellationException : public runtime_error { public: InvalidCancellationException():runtime_error("Ticket is already cancelled or invalid."){} };

class Flight {
protected:
    string number, origin, destination, date, time;
    int capacity, booked;
public:
    Flight(string n,string o,string d,string dt,string tm,int c):number(n),origin(o),destination(d),date(dt),time(tm),capacity(c),booked(0){}
    virtual ~Flight()=default;
    virtual double calculateBaseFare() const=0;
    virtual string type() const=0;
    virtual void displayDetails() const {
        cout<<left<<setw(10)<<number<<setw(15)<<origin<<setw(15)<<destination
            <<setw(13)<<date<<setw(10)<<time<<setw(10)<<booked<<"/"<<capacity
            <<setw(15)<<fixed<<setprecision(2)<<calculateBaseFare()<<type()<<'\n';
    }
    string getNumber() const{return number;}
    string getOrigin() const{return origin;}
    string getDestination() const{return destination;}
    string getDate() const{return date;}
    int seatsLeft() const{return capacity-booked;}
    int getBooked() const{return booked;}
    int getCapacity() const{return capacity;}
    void addSeat(){if(booked>=capacity) throw FlightFullException(); ++booked;}
    void releaseSeat(){if(booked>0)--booked;}
    friend ostream& operator<<(ostream& out,const Flight& f){out<<f.number<<" "<<f.origin<<" -> "<<f.destination<<" ("<<f.type()<<")";return out;}
};
class DomesticFlight:public Flight{
    string region;
public:
    DomesticFlight(string n,string o,string d,string dt,string tm,int c,string r):Flight(n,o,d,dt,tm,c),region(r){}
    double calculateBaseFare()const override{return capacity>=100?100:90;}
    string type()const override{return "Domestic";}
};
class InternationalFlight:public Flight{
    string country; bool visaRequired;
public:
    InternationalFlight(string n,string o,string d,string dt,string tm,int c,string co,bool v):Flight(n,o,d,dt,tm,c),country(co),visaRequired(v){}
    double calculateBaseFare()const override{return capacity>=200?400:350;}
    string type()const override{return "International";}
};
class CharterFlight:public Flight{
    string contractHolder;
public:
    CharterFlight(string n,string o,string d,string dt,string tm,int c,string h):Flight(n,o,d,dt,tm,c),contractHolder(h){}
    double calculateBaseFare()const override{return 600;}
    string type()const override{return "Charter";}
};

class Passenger {
protected:
    string id,name,email; int points=0;
public:
    Passenger(string i,string n,string e):id(i),name(n),email(e){}
    virtual ~Passenger()=default;
    virtual int baggageAllowance()const=0;
    virtual double loyaltyMultiplier()const=0;
    virtual double getRefundPercentage(int days)const=0;
    string getId()const{return id;}
    string getName()const{return name;}
    void addPoints(double fare){points+=static_cast<int>(fare*loyaltyMultiplier()/10);}
    virtual string type()const=0;
    friend ostream& operator<<(ostream& out,const Passenger& p){out<<p.id<<" | "<<p.name<<" | "<<p.type()<<" | "<<p.email;return out;}
};
class EconomyPassenger:public Passenger{
public: using Passenger::Passenger;
    int baggageAllowance()const override{return 20;}
    double loyaltyMultiplier()const override{return 1.0;}
    double getRefundPercentage(int days)const override{return days>7?0.50:0.20;}
    string type()const override{return "Economy";}
};
class BusinessPassenger:public Passenger{
public: using Passenger::Passenger;
    int baggageAllowance()const override{return 32;}
    double loyaltyMultiplier()const override{return 1.5;}
    double getRefundPercentage(int days)const override{return days>3?0.75:0.40;}
    string type()const override{return "Business";}
};
class FirstClassPassenger:public Passenger{
public: using Passenger::Passenger;
    int baggageAllowance()const override{return 50;}
    double loyaltyMultiplier()const override{return 2.0;}
    double getRefundPercentage(int days)const override{return days>1?0.90:0.60;}
    string type()const override{return "First Class";}
};

enum class BookingStatus { Confirmed, Cancelled };
class Ticket {
    static int counter;
    string id, passengerId, flightNo, seat;
    double fare; BookingStatus status;
public:
    Ticket(string p,string f,string s,double amount):passengerId(p),flightNo(f),seat(s),fare(amount),status(BookingStatus::Confirmed){
        ostringstream os;os<<"TKT"<<setw(4)<<setfill('0')<<counter++;id=os.str();
    }
    string getId()const{return id;}
    string getPassengerId()const{return passengerId;}
    string getFlightNo()const{return flightNo;}
    double getFare()const{return fare;}
    bool active()const{return status==BookingStatus::Confirmed;}
    void cancel(){if(!active())throw InvalidCancellationException();status=BookingStatus::Cancelled;}
    friend ostream& operator<<(ostream& out,const Ticket& t){out<<t.id<<" | Passenger: "<<t.passengerId<<" | Flight: "<<t.flightNo<<" | Seat: "<<t.seat<<" | Fare: $"<<t.fare<<" | "<<(t.active()?"Confirmed":"Cancelled");return out;}
    friend bool operator==(const Ticket&a,const Ticket&b){return a.id==b.id;}
};
int Ticket::counter=1;

template<class T,class F>
shared_ptr<T> findFirst(const vector<shared_ptr<T>>& items,F predicate){
    auto it=find_if(items.begin(),items.end(),predicate);
    return it==items.end()?nullptr:*it;
}
class Airline {
    vector<shared_ptr<Flight>> flights;
    vector<shared_ptr<Passenger>> passengers;
    vector<shared_ptr<Ticket>> tickets;
    map<string,vector<string>> history;
    int seatCounter=1;
public:
    void addFlight(shared_ptr<Flight> f){
        if(findFirst(flights,[&](auto x){return x->getNumber()==f->getNumber();}))throw runtime_error("Flight number already exists.");
        flights.push_back(f);cout<<"Flight added successfully.\n";
    }
    void addPassenger(shared_ptr<Passenger> p){
        if(findFirst(passengers,[&](auto x){return x->getId()==p->getId();}))throw runtime_error("Passenger ID already exists.");
        passengers.push_back(p);cout<<"Passenger added successfully.\n";
    }
    void listFlights()const{
        if(flights.empty()){cout<<"No flights available.\n";return;}
        cout<<left<<setw(10)<<"Number"<<setw(15)<<"Origin"<<setw(15)<<"Destination"<<setw(13)<<"Date"<<setw(10)<<"Time"<<"Booked/Capacity  Fare       Type\n";
        for(auto& f:flights)f->displayDetails();
    }
    void listPassengers()const{for(auto&p:passengers)cout<<*p<<'\n';}
    void bookTicket(string pid,string fn){
        auto p=findFirst(passengers,[&](auto x){return x->getId()==pid;});
        auto f=findFirst(flights,[&](auto x){return x->getNumber()==fn;});
        if(!p||!f)throw NotFoundException();
        for(auto&t:tickets)if(t->active()&&t->getPassengerId()==pid&&t->getFlightNo()==fn)throw DuplicateBookingException();
        f->addSeat();
        double fare=f->calculateBaseFare();
        if(p->type()=="Business")fare*=2.0; else if(p->type()=="First Class")fare*=3.0;
        string seat="A"+to_string(seatCounter++);
        auto t=make_shared<Ticket>(pid,fn,seat,fare);tickets.push_back(t);
        history[pid].push_back(t->getId());p->addPoints(fare);
        cout<<"Booking confirmed: "<<*t<<'\n';
    }
    void cancelTicket(string tid,int days){
        auto t=findFirst(tickets,[&](auto x){return x->getId()==tid;});
        if(!t)throw NotFoundException();
        auto p=findFirst(passengers,[&](auto x){return x->getId()==t->getPassengerId();});
        auto f=findFirst(flights,[&](auto x){return x->getNumber()==t->getFlightNo();});
        if(!p||!f)throw NotFoundException();
        double refund=t->getFare()*p->getRefundPercentage(days);
        t->cancel();f->releaseSeat();
        cout<<"Ticket cancelled. Refund: $"<<fixed<<setprecision(2)<<refund<<'\n';
    }
    void routeSearch(string o,string d)const{
        bool found=false;for(auto&f:flights)if(f->getOrigin()==o&&f->getDestination()==d){cout<<*f<<'\n';found=true;}
        if(!found)cout<<"No matching route.\n";
    }
    void occupancyReport()const{
        auto copy=flights;sort(copy.begin(),copy.end(),[](auto&a,auto&b){return double(a->getBooked())/a->getCapacity()>double(b->getBooked())/b->getCapacity();});
        for(auto&f:copy)cout<<f->getNumber()<<" occupancy: "<<(100.0*f->getBooked()/f->getCapacity())<<"%\n";
    }
    void revenueReport()const{
        map<string,double> revenue;for(auto&t:tickets)if(t->active())revenue[t->getFlightNo()]+=t->getFare();
        vector<pair<string,double>> rows(revenue.begin(),revenue.end());
        sort(rows.begin(),rows.end(),[](auto&a,auto&b){return a.second>b.second;});
        cout<<"Top revenue flights:\n";for(size_t i=0;i<rows.size()&&i<5;i++)cout<<rows[i].first<<" : $"<<rows[i].second<<'\n';
    }
    void todayDepartures()const{
        time_t now=time(nullptr);tm* t=localtime(&now);char buf[11];strftime(buf,sizeof(buf),"%Y-%m-%d",t);
        for(auto&f:flights)if(f->getDate()==buf)cout<<*f<<'\n';
    }
    void saveToFile()const{
        ofstream out("skylink_data.txt");
        for(auto&f:flights)out<<"FLIGHT|"<<f->getNumber()<<"|"<<f->getOrigin()<<"|"<<f->getDestination()<<"|"<<f->getDate()<<"\n";
        for(auto&p:passengers)out<<"PASSENGER|"<<p->getId()<<"|"<<p->getName()<<"|"<<p->type()<<"\n";
        cout<<"Basic flight/passenger data saved to skylink_data.txt\n";
    }
    void loadFromFile(){
        ifstream in("skylink_data.txt");if(!in){cout<<"No previous data file. Starting fresh.\n";return;}
        cout<<"Data file found. This demo version saves records for reference; add records again after restart.\n";
    }
};
int main(){
    Airline airline;airline.loadFromFile();
    int choice;
    do{
        cout<<"\n===== SKYLINK AIRWAYS =====\n1 Add Flight\n2 Add Passenger\n3 List Flights\n4 List Passengers\n5 Book Ticket\n6 Cancel Ticket\n7 Search Route\n8 Occupancy Report\n9 Revenue Report\n10 Today's Departures\n11 Save\n0 Exit\nChoice: ";
        if(!(cin>>choice)){cin.clear();cin.ignore(10000,'\n');cout<<"Invalid input.\n";continue;}
        try{
            string a,b,c,d,e;int n,type;
            switch(choice){
            case 1:
                cout<<"Type (1 Domestic, 2 International, 3 Charter): ";cin>>type;
                cout<<"Flight no origin destination date(YYYY-MM-DD) time capacity: ";cin>>a>>b>>c>>d>>e>>n;
                if(type==1){cout<<"Region: ";cin>>a; /* region is optional label */ airline.addFlight(make_shared<DomesticFlight>(b,c,d,e,"09:00",n,a));}
                else if(type==2){string country;int visa;cout<<"Country and visa required (1 yes/0 no): ";cin>>country>>visa;airline.addFlight(make_shared<InternationalFlight>(a,b,c,d,e,n,country,visa!=0));}
                else if(type==3){cout<<"Contract holder: ";cin>>a;airline.addFlight(make_shared<CharterFlight>(b,c,d,e,"09:00",n,a));}
                else cout<<"Invalid type.\n";break;
            case 2:
                cout<<"Passenger type (1 Economy, 2 Business, 3 First): ";cin>>type;
                cout<<"ID name email: ";cin>>a>>b>>c;
                if(type==1)airline.addPassenger(make_shared<EconomyPassenger>(a,b,c));
                else if(type==2)airline.addPassenger(make_shared<BusinessPassenger>(a,b,c));
                else if(type==3)airline.addPassenger(make_shared<FirstClassPassenger>(a,b,c));
                else cout<<"Invalid type.\n";break;
            case 3:airline.listFlights();break;
            case 4:airline.listPassengers();break;
            case 5:cout<<"Passenger ID and flight number: ";cin>>a>>b;airline.bookTicket(a,b);break;
            case 6:cout<<"Ticket ID and days before departure: ";cin>>a>>n;airline.cancelTicket(a,n);break;
            case 7:cout<<"Origin and destination: ";cin>>a>>b;airline.routeSearch(a,b);break;
            case 8:airline.occupancyReport();break;
            case 9:airline.revenueReport();break;
            case 10:airline.todayDepartures();break;
            case 11:airline.saveToFile();break;
            case 0:airline.saveToFile();cout<<"Goodbye!\n";break;
            default:cout<<"Invalid choice.\n";
            }
        }catch(const exception& ex){cout<<"Error: "<<ex.what()<<'\n';}
    }while(choice!=0);
    return 0;
}
