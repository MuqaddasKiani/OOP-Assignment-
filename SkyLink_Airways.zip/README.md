# SkyLink Airways
## Airline Reservation & Flight Management System

**Course:** Object Oriented Programming (C++)  
**Student:** Muqaddas Kiani  
**Roll No.:** 2024-SE-23  
**Instructor:** Engr. Zeeshan  
**Department:** Software Engineering  
**University:** The University of Azad Jammu & Kashmir, Muzaffarabad

---

## 1. Project Overview
SkyLink Airways is a console-based C++ application for managing airline flights, passengers, ticket bookings, cancellations, and basic business reports. It demonstrates core Object-Oriented Programming concepts and uses standard C++ library containers and algorithms.

## 2. Features
- Add domestic, international, and charter flights
- Register Economy, Business, and First Class passengers
- List flights and passengers
- Book and cancel tickets with class-specific refund percentages
- Search flights by origin and destination
- Display flight occupancy and top revenue reports
- Show departures scheduled for the computer's current date
- Save basic flight and passenger information to a text file
- Handle common errors using exceptions

## 3. OOP Concepts Used
- **Encapsulation:** Class data and operations are grouped together.
- **Abstraction:** `Flight` and `Passenger` are abstract base classes.
- **Inheritance:** Specific flight and passenger classes derive from their base classes.
- **Polymorphism:** Virtual functions implement different fares, passenger types, baggage limits, and refund rules.
- **Operator overloading:** `<<` displays objects; `==` compares ticket IDs.
- **Templates:** A generic `findFirst` helper searches collections.
- **Exception handling:** Custom exceptions report full flights, missing records, duplicate bookings, and invalid cancellations.

## 4. Requirements
- C++17-compatible compiler (for example, g++ or a recent Visual Studio compiler)
- VS Code or another C++ editor/IDE (optional)
- Terminal/command prompt

## 5. How to Compile and Run

### Windows (g++)
Open a terminal in the folder containing `SkyLink_Airways.cpp`, then run:

```bash
g++ -std=c++17 SkyLink_Airways.cpp -o SkyLink_Airways.exe
.\SkyLink_Airways.exe
```

### Linux / macOS
```bash
g++ -std=c++17 SkyLink_Airways.cpp -o SkyLink_Airways
./SkyLink_Airways
```

## 6. Menu Guide
| Option | Action |
|---|---|
| 1 | Add Flight |
| 2 | Add Passenger |
| 3 | List Flights |
| 4 | List Passengers |
| 5 | Book Ticket |
| 6 | Cancel Ticket |
| 7 | Search Route |
| 8 | Occupancy Report |
| 9 | Revenue Report |
| 10 | Today's Departures |
| 11 | Save |
| 0 | Save and Exit |

## 7. Important Notes / Current Implementation Limits
- The current save function writes basic flight and passenger information to `skylink_data.txt`; it does not restore records automatically on the next run.
- Ticket records and booking history are not persisted.
- Date input for flights should use `YYYY-MM-DD`.
- The current menu uses simple space-separated input, so enter names, cities, and email values without spaces.
- Seat labels are generated sequentially in the form `A1`, `A2`, and so on.
- The displayed fare multipliers are implemented as Economy = base fare, Business = 2× base fare, and First Class = 3× base fare. Confirm these fare rules with the assignment requirements if they differ.

## 8. Files
- `SkyLink_Airways.cpp` — C++ source code
- `README.md` — project information and run instructions
- `skylink_data.txt` — created when the program saves data

## 9. Academic Note
Review the source code and make sure you can explain each class, virtual function, template, exception, STL container, and report during your viva. Update the student and project details if needed.
