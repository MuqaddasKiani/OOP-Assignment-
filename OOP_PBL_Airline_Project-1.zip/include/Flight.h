
#ifndef FLIGHT_H
#define FLIGHT_H
#include <iostream>
#include <string>
class Flight{
protected:
    std::string flightNo,origin,destination,date;
    int totalSeats,availableSeats;
public:
    Flight(std::string fn="",std::string o="",std::string d="",std::string dt="",int ts=0)
    :flightNo(fn),origin(o),destination(d),date(dt),totalSeats(ts),availableSeats(ts){}
    virtual double calculateBaseFare() const = 0;
    virtual void displayDetails() const = 0;
    virtual ~Flight()=default;
    friend std::ostream& operator<<(std::ostream& os,const Flight& f){
        os<<f.flightNo<<" "<<f.origin<<"->"<<f.destination;
        return os;
    }
};
#endif
