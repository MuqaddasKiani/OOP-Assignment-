
#ifndef TICKET_H
#define TICKET_H
#include <string>
class Ticket{
    int ticketId;
public:
    Ticket(int id=0):ticketId(id){}
    bool operator==(const Ticket& other) const{
        return ticketId==other.ticketId;
    }
};
#endif
