
#ifndef PASSENGER_H
#define PASSENGER_H
#include <string>
class Passenger{
protected:
    int id;
    std::string name;
public:
    Passenger(int i=0,std::string n=""):id(i),name(n){}
    virtual double refundPercentage() const =0;
    virtual ~Passenger()=default;
};
class EconomyPassenger: public Passenger{
public:
    using Passenger::Passenger;
    double refundPercentage() const override { return 0.5; }
};
class BusinessPassenger: public Passenger{
public:
    using Passenger::Passenger;
    double refundPercentage() const override { return 0.75; }
};
class FirstClassPassenger: public Passenger{
public:
    using Passenger::Passenger;
    double refundPercentage() const override { return 0.9; }
};
#endif
