
#include <iostream>
int main(){
    std::cout<<"Airline Reservation System Prototype\n";
    return 0;
}
