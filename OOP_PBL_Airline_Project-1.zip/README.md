# Airline Reservation & Flight Management System
Build:
g++ -std=c++17 src/*.cpp -Iinclude -o airline
Run:
./airline
